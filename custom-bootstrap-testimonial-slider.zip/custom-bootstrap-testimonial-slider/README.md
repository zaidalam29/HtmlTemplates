# Custom bootstrap Testimonial slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/Baky-billah/pen/KYLoyr](https://codepen.io/Baky-billah/pen/KYLoyr).

